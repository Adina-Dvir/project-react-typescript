import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { addProfessional } from '../services/professionalApi';
import { getCategory, addCategory } from '../services/categoryApi';
import type { AddProfessionalForm } from '../type/professionalType';
import '../css/addProfessional.css';

interface Category {
  categoryId: number;
  categoryName: string;
}

export default function AddProfessional() {
  const [formData, setFormData] = useState<Partial<AddProfessionalForm>>({});
  const [images, setImages] = useState<File[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCategoryId, setSelectedCategoryId] = useState<number | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [newCategory, setNewCategory] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      alert('עליך להתחבר לפני הוספת עסק');
      navigate('/login');
    }

    getCategory()
      .then((res) => setCategories(res))
      .catch(console.error);
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setImages(Array.from(e.target.files));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const data = new FormData();

    if (formData.ProfessionalName) data.append("ProfessionalName", formData.ProfessionalName);
    if (formData.ProfessionalPhone) data.append("ProfessionalPhone", formData.ProfessionalPhone);
    if (formData.ProfessionalEmail) data.append("ProfessionalEmail", formData.ProfessionalEmail);
    if (formData.ProfessionalAdress) data.append("ProfessionalAdress", formData.ProfessionalAdress);
    if (formData.City) data.append("City", formData.City);
    if (formData.ProfessionalDescription) data.append("ProfessionalDescription", formData.ProfessionalDescription);
    if (formData.ProfessionalPlace) data.append("ProfessionalPlace", formData.ProfessionalPlace);
    if (formData.PriceRange) data.append("PriceRange", formData.PriceRange);
    if (formData.ProfessionalPassword) data.append("ProfessionalPassword", formData.ProfessionalPassword);

    if (selectedCategoryId !== null) {
      data.append("CategoryId", selectedCategoryId.toString());
    }

    images.forEach((img) => {
      data.append("fileImages", img);
    });

    const token = localStorage.getItem("token");

    try {
      await addProfessional(data);
      alert("העסק נוסף בהצלחה!");
      navigate("/professionals");
    } catch (error: any) {
      alert("שגיאה בהוספה: " + (error.response?.data || ""));
      console.error(error);
    }
  };

  const handleAddCategory = async () => {
    if (!newCategory) return;
    try {
      const added = await addCategory({
        categoryName: newCategory,
        categoryDescription: 'תיאור ברירת מחדל',
        professionals: []
      });

      setCategories([...categories, added]);
      setSelectedCategoryId(added.categoryId);
      setNewCategory('');
      setShowModal(false);
    } catch (error) {
      alert('שגיאה בהוספת הקטגוריה');
    }
  };

  return (
    <div className="form-container">
      <form onSubmit={handleSubmit} className="add-form">
        <h2>הוספת עסק חדש</h2>
        <input name="ProfessionalName" placeholder="שם העסק" onChange={handleChange} required />
        <input name="ProfessionalPhone" placeholder="טלפון" onChange={handleChange} required />
        <input name="ProfessionalEmail" placeholder="אימייל" onChange={handleChange} />
        <input name="ProfessionalAdress" placeholder="כתובת" onChange={handleChange} />
        <input name="ProfessionalPassword" placeholder="סיסמא" onChange={handleChange} />

        <input name="City" placeholder="עיר" onChange={handleChange} />
        <input name="ProfessionalDescription" placeholder="תיאור" onChange={handleChange} />
        <input name="professionalPlace" placeholder="אזור" onChange={handleChange} />
        <input name="PriceRange" placeholder="טווח מחירים" onChange={handleChange} />

        <label>קטגוריה:</label>
        <select onChange={(e) => {
          const value = e.target.value;
          if (value === '__add_new__') {
            setShowModal(true);
          } else {
            setSelectedCategoryId(Number(value));
          }
        }} value={selectedCategoryId?.toString() || ''}>
          <option value="">בחר קטגוריה</option>
          {categories.map(cat => (
            <option key={cat.categoryId} value={cat.categoryId}>
              {cat.categoryName}
            </option>
          ))}
          <option value="__add_new__">➕ הוסף קטגוריה חדשה</option>
        </select>

        <label>תמונות:</label>
        <input type="file" multiple onChange={handleFileChange} />

        <button type="submit">שלח</button>
      </form>

      {showModal && (
        <div className="modal-overlay">
          <div className="modal">
            <h3>הוספת קטגוריה חדשה</h3>
            <input
              type="text"
              placeholder="שם הקטגוריה"
              value={newCategory}
              onChange={(e) => setNewCategory(e.target.value)}
            />
            <div className="modal-buttons">
              <button onClick={handleAddCategory}>שמור</button>
              <button onClick={() => setShowModal(false)}>ביטול</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
