export interface EmailDetails {
  recipient: string;
  subject: string;
  msgBody: string;
  mambers?: string;
  attachment?: string;
}
